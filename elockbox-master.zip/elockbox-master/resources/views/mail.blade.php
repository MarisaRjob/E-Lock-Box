<img src="{{$message->embed($imgPath)}}" /><br>
<p>Dear {{$name}},</p>
<br>
<p>Your verification code is <b style="color: red">{{$code}}</b>.</p>
<p>This code can be used only one time.</p>
<br>
<p><b style="color: black">Please do not reply.</b></p>
<p>For more information, please contact <a href="mailto:info@LivingAdvantageInc.org">info@LivingAdvantageInc.org</a> or visit <a href="www.mylaspace.com">www.mylaspace.com</a>.</p>
<br>
<p>Living Advantage Inc.</p>
<p>Elockbox</p>
<p><em>Developed by USC Team 10</em></p>